<?php
	// Página que remove produtos do banco de dados
	include("conecta.php");
	include("banco-produto.php");

	$id = $_POST["id"];
	removeProduto($conexao,$id);
	header("Location: lista-produto.php?removido=true");
	die();
?>