<?php include("header.php");?>


	<h1>Bem Vindo!</h1>

<?php include("footer.php");?>		