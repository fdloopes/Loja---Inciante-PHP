<?php
	// Realiza a conexão com o banco	
	$conexao = mysqli_connect('localhost','root','root','loja');